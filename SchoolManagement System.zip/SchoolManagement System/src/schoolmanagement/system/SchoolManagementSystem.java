/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package schoolmanagement.system;

import java.util.HashSet;
import java.util.Set;
import java.sql.*;

/**
 *
 * @author it's Anivesh
 */
public class SchoolManagementSystem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        LoginPage LoginPageFrame = new LoginPage();
        LoginPageFrame.setVisible(true);
        LoginPageFrame.pack();
        LoginPageFrame.setLocationRelativeTo(null);
        
    }
    
}
